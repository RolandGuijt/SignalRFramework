﻿namespace WiredBrain.Orders
{
    public class UpdateInfo
    {
        public int OrderId { get; set; }
        public string Update { get; set; }
        public bool Finished { get; set; }
    }
}
